/* Simple simulation script: queue, autoscaling visuals */
let queue = 0;
let autoscaling = true;
let publicCount = 2;
let privateCount = 1;
const maxPublic = 6;
const minPublic = 2;
const processRate = 4; // requests processed per tick per instance
const tick = 1500; // ms

// init UI elements
const qEl = document.getElementById('queue');
const pcountEl = document.getElementById('pcount');
const prcountEl = document.getElementById('prcount');
const autosEl = document.getElementById('autos');
const autosStateEl = document.getElementById('autosState');

function refreshUI(){
  qEl.innerText = queue;
  pcountEl.innerText = publicCount;
  prcountEl.innerText = privateCount;
  autosEl.innerText = autoscaling ? 'ON' : 'OFF';
  autosStateEl.innerText = autoscaling ? 'ON' : 'OFF';
  // update server boxes
  const publicServers = document.getElementById('public-servers');
  const privateServers = document.getElementById('private-servers');
  publicServers.innerHTML = '';
  privateServers.innerHTML = '';
  for(let i=0;i<publicCount;i++){
    const d = document.createElement('div'); d.className='server active'; d.innerText = 'Public-'+(i+1);
    if (i>=2) d.classList.add('scaled');
    publicServers.appendChild(d);
  }
  for(let i=0;i<privateCount;i++){
    const d = document.createElement('div'); d.className='server active'; d.innerText = 'Private-'+(i+1);
    privateServers.appendChild(d);
  }
}

// simulate processing per tick
function tickProcess(){
  // capacity from public + private
  const capacity = (publicCount + privateCount) * processRate;
  const processed = Math.min(queue, capacity);
  queue -= processed;
  // if autoscaling enabled, decide scale up/down based on queue length per server
  if (autoscaling){
    const loadPerServer = queue / Math.max(1, publicCount + privateCount);
    // scale up when load per server > 6
    if (loadPerServer > 6 && publicCount < maxPublic){
      publicCount += 1;
      flashMessage('Auto-scaling: added 1 public server');
    }
    // scale down when very low and above minPublic
    if (loadPerServer < 2 && publicCount > minPublic){
      publicCount -= 1;
      flashMessage('Auto-scaling: removed 1 public server');
    }
  }
  refreshUI();
}

// send requests
function sendRequests(n){
  queue += n;
  animateFlow(n);
  refreshUI();
}

// simple flow animation by creating moving dots near load balancer
function animateFlow(n){
  const lb = document.getElementById('lb');
  for(let i=0;i<Math.min(8, Math.max(1, Math.round(n/2))); i++){
    const dot = document.createElement('div');
    dot.className = 'flow';
    dot.style.left = (lb.getBoundingClientRect().left + window.scrollX) + 'px';
    dot.style.top = (lb.getBoundingClientRect().top + window.scrollY + 20 + i*6) + 'px';
    const inner = document.createElement('div'); inner.className='dot';
    dot.appendChild(inner);
    document.body.appendChild(dot);
    // animate using CSS keyframes by setting transform over time (simple fade using timeout)
    setTimeout(()=> dot.remove(), 2200);
  }
}

// toggle auto-scaling
function toggleAuto(){
  autoscaling = !autoscaling;
  refreshUI();
  flashMessage('Auto-scaling ' + (autoscaling ? 'enabled' : 'disabled'));
}

function resetSim(){
  queue = 0; publicCount = 2; privateCount = 1; autoscaling = true;
  refreshUI();
  flashMessage('Simulation reset');
}

// small toast message
function flashMessage(msg){
  let t = document.createElement('div');
  t.innerText = msg; t.style.position='fixed'; t.style.right='20px'; t.style.bottom='20px';
  t.style.background='rgba(0,0,0,0.75)'; t.style.color='white'; t.style.padding='8px 12px'; t.style.borderRadius='6px';
  document.body.appendChild(t);
  setTimeout(()=> t.remove(), 2600);
}

// start tick
refreshUI();
setInterval(tickProcess, tick);
