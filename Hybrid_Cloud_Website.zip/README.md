# Hybrid Cloud Computing Model — Interactive Demo (Static Website)

This is a **static, single-page**, animated website that demonstrates the working of a Hybrid Cloud model (Public + Private Cloud, Load Balancer, Auto-scaling).

## Files
- `index.html` — main page (open directly in browser)
- `style.css` — styling & animations
- `script.js` — simulation logic (queue, autoscaling, visuals)
- `README.md` — this file

## How to use (locally)
1. Unzip the project folder.
2. Open `index.html` in any modern browser (Chrome/Firefox). No server required.
3. Click the buttons to simulate requests and watch auto-scaling behavior.

## How to host for free (GitHub Pages)
1. Create a new GitHub repository and commit the files (index.html, style.css, script.js).
2. Go to the repository → Settings → Pages.
3. Under "Build and deployment", select **Deploy from a branch**, choose **main** branch and `/ (root)` folder, then save.
4. GitHub will publish your site at `https://<username>.github.io/<repo>` within a minute.

Alternatively, drag-and-drop the ZIP into **Netlify** or **Vercel** for instant hosting (no server needed).

---
Project by: **Sanskriti Singh** — Kalinga Institute of Industrial Technology
